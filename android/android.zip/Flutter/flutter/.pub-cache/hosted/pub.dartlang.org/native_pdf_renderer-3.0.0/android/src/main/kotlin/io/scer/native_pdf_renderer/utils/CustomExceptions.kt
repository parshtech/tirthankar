package io.scer.native_pdf_renderer.utils

import java.lang.Exception

class CreateRendererException: Exception()
