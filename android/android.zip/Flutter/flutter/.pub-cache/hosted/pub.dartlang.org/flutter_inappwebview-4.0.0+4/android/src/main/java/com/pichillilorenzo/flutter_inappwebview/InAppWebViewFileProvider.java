package com.pichillilorenzo.flutter_inappwebview;

import androidx.core.content.FileProvider;

public class InAppWebViewFileProvider extends FileProvider {

  // This class intentionally left blank.

}
