package com.dexterous.flutterlocalnotifications;

public enum NotificationStyle{
    Default,
    BigText,
    Inbox
}
